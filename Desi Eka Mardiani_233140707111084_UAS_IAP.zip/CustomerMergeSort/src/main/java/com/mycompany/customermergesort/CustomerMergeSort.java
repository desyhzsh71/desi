package com.mycompany.customermergesort;
import java.util.Arrays; 

/**
 *
 * @author shiah
 */

// Kelas Customer untuk menyimpan data pelanggan
class Customer {
    int id;
    String name;
    double totalSpending;
    
    Customer(int id, String name, double totalSpending) {
        this.id = id;
        this.name = name;
        this.totalSpending = totalSpending;
    }
    
    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Total Spending: Rp" + totalSpending;
    }
}

public class CustomerMergeSort {
    
    // Metode Merge Sort untuk mengurutkan pelanggan berdasarkan total belanja
    public static void mergeSort(Customer[] customers) {
        if (customers.length <= 1) {
            return;
        }

        // Membagi array menjadi dua bagian
        int mid = customers.length / 2;
        Customer[] left = Arrays.copyOfRange(customers, 0, mid);
        Customer[] right = Arrays.copyOfRange(customers, mid, customers.length);

        // Memanggil mergeSort secara rekursif pada kedua bagian
        mergeSort(left);
        mergeSort(right);

        // Menggabungkan kedua bagian yang sudah terurut
        merge(customers, left, right);
    }
    
    // Metode untuk menggabungkan dua array terurut
    private static void merge(Customer[] customers, Customer[] left, Customer[] right) {
        int i = 0, j = 0, k = 0;

        // Menggabungkan elemen dari left dan right ke dalam customers
        while (i < left.length && j < right.length) {
            if (left[i].totalSpending > right[j].totalSpending) {
                customers[k++] = left[i++];
            } else if (left[i].totalSpending < right[j].totalSpending) {
                customers[k++] = right[j++];
            } else {
                // Jika total spending sama, urutkan berdasarkan ID (untuk menjaga kestabilan)
                if (left[i].id < right[j].id) {
                    customers[k++] = left[i++];
                } else {
                    customers[k++] = right[j++];
                }
            }
        }
        
        // Menyalin sisa elemen
        while (i < left.length) {
            customers[k++] = left[i++];
        }
        while (j < right.length) {
            customers[k++] = right[j++];
        }
    }

    // Metode untuk menampilkan daftar pelanggan
    public static void printCustomers(Customer[] customers) {
        for (Customer customer : customers) {
            System.out.println(customer);
        }
    }

    public static void main(String[] args) {
        // Membuat array pelanggan
        Customer[] customers = {
            new Customer(1, "Shia", 2000000.00),
            new Customer(2, "Khail", 1500000.00),
            new Customer(3, "Iyan", 5000000.00),
            new Customer(4, "Ella", 1000000.00),
            new Customer(5, "Ray", 2500000.00),
        };
        
        // Menampilkan pelanggan sebelum pengurutan
        System.out.println("Data Pelanggan Sebelum Pengurutan : ");
        printCustomers(customers);
        
        // Melakukan pengurutan menggunakan Merge Sort
        mergeSort(customers);
        
        // Menampilkan pelanggan setelah pengurutan
        System.out.println("\nData Pelanggan Setelah Pengurutan : ");
        printCustomers(customers);
    }
}

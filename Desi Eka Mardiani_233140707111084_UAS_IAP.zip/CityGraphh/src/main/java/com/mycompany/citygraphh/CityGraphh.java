package com.mycompany.citygraphh;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author shiah
 */

// Kelas untuk merepresentasikan sebuah jalan antar kota (edge)
class Edge {
    int destination;  // Kota tujuan
    int cost;         // Biaya atau waktu tempuh

    public Edge(int destination, int cost) {
        this.destination = destination;
        this.cost = cost;
    }

    @Override
    public String toString() {
        return "To: " + destination + ", Cost: " + cost;
    }
}

// Kelas untuk merepresentasikan graf kota
class Graph {
    List<List<Edge>> adjList;  // Daftar adjacency untuk graf

    public Graph(int numCities) {
        adjList = new ArrayList<>();
        for (int i = 0; i < numCities; i++) {
            adjList.add(new ArrayList<>());  // Setiap kota memiliki daftar tetangga
        }
    }

    // Menambahkan jalan antara dua kota
    public void addEdge(int source, int destination, int cost) {
        adjList.get(source).add(new Edge(destination, cost));    // Menambahkan jalur ke kota tujuan
        adjList.get(destination).add(new Edge(source, cost));    // Karena graf tidak berarah
    }

    // Menampilkan graf dalam format adjacency list
    public void displayGraph() {
        for (int i = 0; i < adjList.size(); i++) {
            System.out.println("Kota " + i + " -> " + adjList.get(i));
        }
    }
}

public class CityGraphh {
    public static void main(String[] args) {
        int numCities = 5;  // Jumlah kota
        Graph graph = new Graph(numCities);

        // Menambahkan jalan antar kota
        graph.addEdge(0, 1, 10); // Jalan antara kota 0 dan 1 dengan biaya 10
        graph.addEdge(0, 2, 3);  // Jalan antara kota 0 dan 2 dengan biaya 3
        graph.addEdge(1, 2, 1);  // Jalan antara kota 1 dan 2 dengan biaya 1
        graph.addEdge(1, 3, 2);  // Jalan antara kota 1 dan 3 dengan biaya 2
        graph.addEdge(2, 3, 8);  // Jalan antara kota 2 dan 3 dengan biaya 8
        graph.addEdge(3, 4, 7);  // Jalan antara kota 3 dan 4 dengan biaya 7

        // Menampilkan graf
        System.out.println("Graf Kota (Adjacency List):");
        graph.displayGraph();
    }
}

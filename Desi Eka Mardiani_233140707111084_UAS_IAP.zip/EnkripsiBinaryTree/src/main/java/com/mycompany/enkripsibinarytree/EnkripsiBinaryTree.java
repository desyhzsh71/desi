package com.mycompany.enkripsibinarytree;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
/**
 *
 * @author shiah
 */

class EncryptedData {
    String encryptedId;
    String encryptedData;
    
    public EncryptedData(String id, String data, Key secretKey) throws Exception {
        this.encryptedId = encrypt(id, secretKey);
        this.encryptedData = encrypt(data, secretKey);
    }
    
    public static String encrypt(String data, Key secretKey) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(data.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }
    
    public static String decrypt(String encryptedData, Key secretKey) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedData));
        return new String(decryptedBytes);
    }
}

class EncryptedNode {
    EncryptedData data;
    EncryptedNode left;
    EncryptedNode right;
    
    public EncryptedNode(EncryptedData data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

public class EnkripsiBinaryTree {

    private EncryptedNode root;
    private Key secretKey;
    
    public EnkripsiBinaryTree() throws Exception {
        // Inisialisasi kunci enkripsi
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(256);
        this.secretKey = keyGen.generateKey();
    }
    
    // Metode untuk menyisipkan data terenkripsi
    public void insert(String id, String userData) throws Exception {
        EncryptedData encryptedData = new EncryptedData(id, userData, secretKey);
        root = insertRec(root, encryptedData);
    }
    
    private EncryptedNode insertRec(EncryptedNode root, EncryptedData encryptedData) throws Exception {
        if (root == null) {
            return new EncryptedNode(encryptedData);
        }
        
        // Dekripsi untuk perbandingan
        String currentId = EncryptedData.decrypt(root.data.encryptedId, secretKey);
        String newId = EncryptedData.decrypt(encryptedData.encryptedId, secretKey);
        
        if (newId.compareTo(currentId) < 0) {
            root.left = insertRec(root.left, encryptedData);
        } else if (newId.compareTo(currentId) > 0) {
            root.right = insertRec(root.right, encryptedData);
        }
        
        return root;
    }
    
    // Metode pencarian data
    public String search(String id) throws Exception {
        EncryptedNode result = searchRec(root, id);
        if (result != null) {
            // Dekripsi data sebelum dikembalikan
            return EncryptedData.decrypt(result.data.encryptedData, secretKey);
        }
        return null;
    }
    
    private EncryptedNode searchRec(EncryptedNode root, String id) throws Exception {
        if (root == null) return null;
        
        // Dekripsi ID untuk perbandingan
        String currentId = EncryptedData.decrypt(root.data.encryptedId, secretKey);
        
        if (currentId.equals(id)) {
            return root;
        }
        
        if (id.compareTo(currentId) < 0) {
            return searchRec(root.left, id);
        }
        
        return searchRec(root.right, id);
    }
    
    // Metode penghapusan data
    public void delete(String id) throws Exception {
        root = deleteRec(root, id);
    }
    
    private EncryptedNode deleteRec(EncryptedNode root, String id) throws Exception {
        if (root == null) return null;
        
        // Dekripsi ID untuk perbandingan
        String currentId = EncryptedData.decrypt(root.data.encryptedId, secretKey);
        
        if (id.compareTo(currentId) < 0) {
            root.left = deleteRec(root.left, id);
        } else if (id.compareTo(currentId) > 0) {
            root.right = deleteRec(root.right, id);
        } else {
            // Node dengan satu atau tanpa anak
            if (root.left == null) return root.right;
            if (root.right == null) return root.left;
            
            // Node dengan dua anak: ambil suksesor in-order (node terkecil di subpohon kanan)
            root.data = findMinNode(root.right);
            root.right = deleteRec(root.right, 
                EncryptedData.decrypt(root.data.encryptedId, secretKey));
        }
        
        return root;
    }
    
    // Metode untuk menemukan node dengan ID terkecil
    private EncryptedData findMinNode(EncryptedNode root) throws Exception {
        EncryptedNode current = root;
        while (current.left != null) {
            current = current.left;
        }
        return current.data;
    }
    
    // Metode untuk menampilkan tree (in-order traversal)
    public void inorderTraversal() throws Exception {
        inorderRec(root);
    }
    
    private void inorderRec(EncryptedNode root) throws Exception {
        if (root != null) {
            inorderRec(root.left);
            System.out.println("ID: " + 
                EncryptedData.decrypt(root.data.encryptedId, secretKey) + 
                ", Data: Terenkripsi");
            inorderRec(root.right);
        }
    }
    
    // Contoh penggunaan
    public static void main(String[] args) {
        try {
            EnkripsiBinaryTree tree = new EnkripsiBinaryTree();
            
            // Penyisipan data
            tree.insert("001", "Data Sensitif Pelanggan A");
            tree.insert("003", "Data Sensitif Pelanggan B");
            tree.insert("002", "Data Sensitif Pelanggan C");
            
            // Pencarian data
            System.out.println("Pencarian data ID 002: " + 
                tree.search("002"));
            
            // Penghapusan data
            tree.delete("003");
            
            // Tampilkan tree
            System.out.println("\nIsi Tree:");
            tree.inorderTraversal();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
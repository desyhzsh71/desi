package com.mycompany.binarysearch;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author shiah
 */

// Kelas untuk mempresentasikan produk
class Product {
    int id;
    String name;
    double price;

    Product(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Price: Rp" + String.format("%.2f", price);
    }
}

// Kelas utama
public class BinarySearch {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Daftar produk yang diurutkan berdasarkan harga
        Product[] products = {
            new Product(1, "Album", 200.00),
            new Product(2, "Photobook", 150.00),
            new Product(3, "Photocard", 100.00),
            new Product(4, "Mini Plush", 140.00),
            new Product(5, "Keychain", 50.00)
        };

        // Mengurutkan daftar produk berdasarkan harga
        Arrays.sort(products, (a, b) -> Double.compare(a.price, b.price));

        System.out.println("Daftar Produk (Diurutkan Berdasarkan Harga):");
        for (Product product : products) {
            System.out.println(product);
        }

        // Pencarian berdasarkan ID
        System.out.print("\nMasukkan ID produk yang ingin dicari: ");
        int targetId = scanner.nextInt();
        Product foundProduct = binarySearchById(products, targetId);

        if (foundProduct != null) {
            System.out.println("Produk ditemukan: " + foundProduct);
        } else {
            System.out.println("Produk dengan ID " + targetId + " tidak ditemukan.");
        }

        // Pencarian berdasarkan rentang harga
        System.out.print("\nMasukkan harga minimum: ");
        double minPrice = scanner.nextDouble();
        System.out.print("Masukkan harga maksimum: ");
        double maxPrice = scanner.nextDouble();
        List<Product> productsInRange = searchByPriceRange(products, minPrice, maxPrice);

        System.out.println("\nPencarian Produk Berdasarkan Rentang Harga:");
        if (!productsInRange.isEmpty()) {
            for (Product product : productsInRange) {
                System.out.println(product);
            }
        } else {
            System.out.println("Tidak ada produk dalam rentang harga tersebut.");
        }

        scanner.close();
    }

    // Metode Binary Search untuk mencari produk berdasarkan ID
    public static Product binarySearchById(Product[] products, int targetId) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (products[mid].id == targetId) {
                return products[mid];
            } else if (products[mid].id < targetId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return null;
    }

    // Metode untuk mencari produk dalam rentang harga tertentu
    public static List<Product> searchByPriceRange(Product[] products, double minPrice, 
            double maxPrice) {
        List<Product> result = new ArrayList<>();
        for (Product product : products) {
            if (product.price >= minPrice && product.price <= maxPrice) {
                result.add(product);
            }
        }
        return result;
    }
}
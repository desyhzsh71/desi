package com.mycompany.dijkstra;
import java.util.*;
/**
 *
 * @author shiah
 */

// Kelas untuk mewakili simpul dalam heap (min-heap)
class Node implements Comparable<Node> {
    int city;  // Kota
    int dist;  // Jarak dari kota sumber

    public Node(int city, int dist) {
        this.city = city;
        this.dist = dist;
    }

    // Untuk memastikan Node bisa diurutkan berdasarkan jarak
    @Override
    public int compareTo(Node other) {
        return Integer.compare(this.dist, other.dist);
    }
}

// Kelas untuk mewakili jalan antar kota (edge)
class Edge {
    int destination;  // Kota tujuan
    int cost;         // Biaya (atau waktu tempuh)

    public Edge(int destination, int cost) {
        this.destination = destination;
        this.cost = cost;
    }
}

// Kelas untuk graf
class Graph {
    List<List<Edge>> adjList;

    public Graph(int numCities) {
        adjList = new ArrayList<>();
        for (int i = 0; i < numCities; i++) {
            adjList.add(new ArrayList<>());
        }
    }

    // Menambahkan jalan antara dua kota
    public void addEdge(int source, int destination, int cost) {
        adjList.get(source).add(new Edge(destination, cost));
        adjList.get(destination).add(new Edge(source, cost)); // Graf tak terarah
    }
}

// Kelas untuk algoritma Dijkstra
public class Dijkstra {

    private Graph graph;

    public Dijkstra(Graph graph) {
        this.graph = graph;
    }

    // Fungsi untuk mencari rute terpendek
    public void findShortestPath(int start, int end) {
        int numCities = graph.adjList.size();
        int[] dist = new int[numCities];
        Arrays.fill(dist, Integer.MAX_VALUE);
        dist[start] = 0;

        // Min-heap untuk menyimpan kota dengan jarak terpendek
        PriorityQueue<Node> minHeap = new PriorityQueue<>();
        minHeap.add(new Node(start, 0));

        while (!minHeap.isEmpty()) {
            Node current = minHeap.poll();
            int city = current.city;
            int currentDist = current.dist;

            // Jika kita sudah mencapai kota tujuan, berhenti
            if (city == end) {
                break;
            }

            // Menelusuri tetangga kota
            for (Edge edge : graph.adjList.get(city)) {
                int neighbor = edge.destination;
                int newDist = currentDist + edge.cost;

                // Jika jarak baru lebih pendek, perbarui dan masukkan ke heap
                if (newDist < dist[neighbor]) {
                    dist[neighbor] = newDist;
                    minHeap.add(new Node(neighbor, newDist));
                }
            }
        }

        // Menampilkan hasil jarak terpendek
        if (dist[end] != Integer.MAX_VALUE) {
            System.out.println("Rute terpendek dari kota " + start + " ke kota " + end + " adalah: " + dist[end]);
        } else {
            System.out.println("Tidak ada rute dari kota " + start + " ke kota " + end);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Jumlah kota dan jalan sudah ditentukan dalam kode
        int numCities = 5;
        Graph graph = new Graph(numCities);

        // Menambahkan jalan antar kota
        graph.addEdge(0, 1, 10); // Jalan antara kota 0 dan 1 dengan biaya 10
        graph.addEdge(0, 2, 3);  // Jalan antara kota 0 dan 2 dengan biaya 3
        graph.addEdge(1, 2, 1);  // Jalan antara kota 1 dan 2 dengan biaya 1
        graph.addEdge(1, 3, 2);  // Jalan antara kota 1 dan 3 dengan biaya 2
        graph.addEdge(2, 3, 8);  // Jalan antara kota 2 dan 3 dengan biaya 8
        graph.addEdge(3, 4, 7);  // Jalan antara kota 3 dan 4 dengan biaya 7

        // Input kota asal dan tujuan
        System.out.print("Masukkan kota asal (0 hingga " + (numCities - 1) + "): ");
        int start = scanner.nextInt();
        System.out.print("Masukkan kota tujuan (0 hingga " + (numCities - 1) + "): ");
        int end = scanner.nextInt();

        // Membuat objek Dijkstra dan mencari rute terpendek
        Dijkstra dijkstra = new Dijkstra(graph);
        dijkstra.findShortestPath(start, end);

        scanner.close();
    }
}
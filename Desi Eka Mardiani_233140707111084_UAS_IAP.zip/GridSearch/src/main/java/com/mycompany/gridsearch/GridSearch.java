package com.mycompany.gridsearch;
import java.util.*;
/**
 *
 * @author shiah
 */

class ObjectInfo {
    String objectType;
    int x, y;
    
    public ObjectInfo(String objectType, int x, int y) {
        this.objectType = objectType;
        this.x = x;
        this.y = y;
    }
    
    public double calculateDistance() {
        return Math.sqrt(x * x + y * y);
    }
    
    @Override
    public String toString() {
        return objectType + " at (" + x + ", " + y + ") with distance: " + String.format
        ("%.2f", calculateDistance());
    }
}

public class GridSearch {
    private static Scanner scanner = new Scanner(System.in);
    
    // Metode untuk menambahkan objek secara manual
    public static ObjectInfo[] inputObjects() {
        System.out.print("Masukkan jumlah objek yang ingin Anda tambahkan : ");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        ObjectInfo[] objects = new ObjectInfo[n];
        
        for (int i = 0; i < n; i++) {
            System.out.println("\nMasukkan detail Objek ke-" + (i + 1));
            
            System.out.print("Jenis Objek : ");
            String objectType = scanner.nextLine();
            
            System.out.print("Koordinat X : ");
            int x = scanner.nextInt();
            
            System.out.print("Koordinat Y : ");
            int y = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            objects[i] = new ObjectInfo(objectType, x, y);
        }
        
        return objects;
    }
    
    // Metode pencarian objek berdasarkan koordinat
    public static ObjectInfo findObjectByCoordinates(ObjectInfo[] objects, int targetX, int targetY) {
        // Urutkan objek berdasarkan jarak
        Arrays.sort(objects, Comparator.comparingDouble(ObjectInfo::calculateDistance));
        
        int left = 0;
        int right = objects.length - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            ObjectInfo midObject = objects[mid];
            
            // Cocokkan koordinat
            if (midObject.x == targetX && midObject.y == targetY) {
                return midObject;
            }
            
            // Tentukan arah pencarian
            if (midObject.x < targetX || (midObject.x == targetX && midObject.y < targetY)) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return null;
    }
    
    // Metode untuk mencari objek terdekat
    public static ObjectInfo findNearestObject(ObjectInfo[] objects) {
        if (objects == null || objects.length == 0) {
            return null;
        }
        
        // Urutkan berdasarkan jarak
        Arrays.sort(objects, Comparator.comparingDouble(ObjectInfo::calculateDistance));
        
        return objects[0];
    }
    
    // Metode untuk mencari objek dalam rentang jarak
    public static ObjectInfo[] findObjectsInRange(ObjectInfo[] objects, double maxDistance) {
        // Urutkan berdasarkan jarak
        Arrays.sort(objects, Comparator.comparingDouble(ObjectInfo::calculateDistance));
        
        // Cari batas objek dalam rentang
        int index = 0;
        for (ObjectInfo obj : objects) {
            if (obj.calculateDistance() > maxDistance) {
                break;
            }
            index++;
        }
        
        return Arrays.copyOfRange(objects, 0, index);
    }
    
    // Menu interaktif
    public static void menuInteraktif() {
        ObjectInfo[] objects = null;
        
        while (true) {
            System.out.println("\n--- MENU PENCARIAN OBJEK GRID 2D ---");
            System.out.println("1. Input Objek");
            System.out.println("2. Cari Objek dengan Koordinat");
            System.out.println("3. Cari Objek Terdekat");
            System.out.println("4. Cari Objek dalam Rentang Jarak");
            System.out.println("5. Keluar");
            System.out.print("Pilih opsi (1-5) : ");
            
            int pilihan = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            switch (pilihan) {
                case 1:
                    objects = inputObjects();
                    System.out.println("Objek berhasil diinput!");
                    break;
                
                case 2:
                    if (objects == null) {
                        System.out.println("Silakan input objek terlebih dahulu!");
                        break;
                    }
                    System.out.print("Masukkan Koordinat X yang dicari : ");
                    int targetX = scanner.nextInt();
                    System.out.print("Masukkan Koordinat Y yang dicari : ");
                    int targetY = scanner.nextInt();
                    
                    ObjectInfo foundObject = findObjectByCoordinates(objects, targetX, targetY);
                    if (foundObject != null) {
                        System.out.println("Objek ditemukan : " + foundObject);
                    } else {
                        System.out.println("Objek tidak ditemukan.");
                    }
                    break;
                
                case 3:
                    if (objects == null) {
                        System.out.println("Silakan input objek terlebih dahulu!");
                        break;
                    }
                    ObjectInfo nearestObject = findNearestObject(objects);
                    System.out.println("Objek Terdekat: " + nearestObject);
                    break;
                
                case 4:
                    if (objects == null) {
                        System.out.println("Silakan input objek terlebih dahulu!");
                        break;
                    }
                    System.out.print("Masukkan jarak maksimum : ");
                    double maxDistance = scanner.nextDouble();
                    
                    ObjectInfo[] objectsInRange = findObjectsInRange(objects, maxDistance);
                    System.out.println("Objek dalam Rentang Jarak :");
                    for (ObjectInfo obj : objectsInRange) {
                        System.out.println(obj);
                    }
                    break;
                
                case 5:
                    System.out.println("Terima kasih!");
                    return;
                
                default:
                    System.out.println("Pilihan tidak valid!");
            }
        }
    }
    
    public static void main(String[] args) {
        menuInteraktif();
    }
}
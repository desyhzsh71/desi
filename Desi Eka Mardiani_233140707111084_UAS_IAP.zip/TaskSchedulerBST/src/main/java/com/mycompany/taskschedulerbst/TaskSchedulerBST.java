package com.mycompany.taskschedulerbst;
import java.util.Scanner;

/**
 *
 * @author shiah
 */

import java.util.Scanner;

class TaskNode {
    int id;
    String deadline; // Format: "yyyy-MM-dd"
    int priority;
    TaskNode left, right;

    public TaskNode(int id, String deadline, int priority) {
        this.id = id;
        this.deadline = deadline;
        this.priority = priority;
        this.left = this.right = null;
    }
}

public class TaskSchedulerBST {
    private TaskNode root;

    // Menambahkan tugas baru
    public void addTask(int id, String deadline, int priority) {
        root = insertTask(root, id, deadline, priority);
    }

    private TaskNode insertTask(TaskNode node, int id, String deadline, int priority) {
        if (node == null) {
            return new TaskNode(id, deadline, priority);
        }
        if (deadline.compareTo(node.deadline) < 0) {
            node.left = insertTask(node.left, id, deadline, priority);
        } else {
            node.right = insertTask(node.right, id, deadline, priority);
        }
        return node;
    }

    // Menghapus tugas berdasarkan ID
    public void removeTask(int id) {
        root = deleteTask(root, id);
    }

    private TaskNode deleteTask(TaskNode node, int id) {
        if (node == null) {
            return null;
        }
        if (id < node.id) {
            node.left = deleteTask(node.left, id);
        } else if (id > node.id) {
            node.right = deleteTask(node.right, id);
        } else {
            // Node ditemukan
            if (node.left == null) return node.right;
            if (node.right == null) return node.left;

            // Node memiliki dua anak
            TaskNode successor = getMinValueNode(node.right);
            node.id = successor.id;
            node.deadline = successor.deadline;
            node.priority = successor.priority;
            node.right = deleteTask(node.right, successor.id);
        }
        return node;
    }

    private TaskNode getMinValueNode(TaskNode node) {
        while (node.left != null) {
            node = node.left;
        }
        return node;
    }

    // Menampilkan semua tugas (traversal inorder)
    public void displayTasks() {
        System.out.println("Tugas-tugas aktif (berdasarkan deadline):");
        inorderTraversal(root);
    }

    private void inorderTraversal(TaskNode node) {
        if (node != null) {
            inorderTraversal(node.left);
            System.out.println("ID: " + node.id + ", Deadline: " + node.deadline + 
                    ", Priority: " + node.priority);
            inorderTraversal(node.right);
        }
    }

    // Menu interaktif
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TaskSchedulerBST scheduler = new TaskSchedulerBST();

        while (true) {
            System.out.println("\n--- Menu Penjadwalan Tugas ---");
            System.out.println("1. Tambah Tugas");
            System.out.println("2. Hapus Tugas Berdasarkan ID");
            System.out.println("3. Tampilkan Semua Tugas");
            System.out.println("4. Keluar");
            System.out.print("Pilih opsi (1-4): ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Konsumsi newline

            switch (choice) {
                case 1:
                    System.out.print("Masukkan ID Tugas: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Konsumsi newline
                    System.out.print("Masukkan Deadline (yyyy-MM-dd): ");
                    String deadline = scanner.nextLine();
                    System.out.print("Masukkan Prioritas: ");
                    int priority = scanner.nextInt();
                    scheduler.addTask(id, deadline, priority);
                    System.out.println("Tugas berhasil ditambahkan.");
                    break;

                case 2:
                    System.out.print("Masukkan ID Tugas yang akan dihapus: ");
                    int deleteId = scanner.nextInt();
                    scheduler.removeTask(deleteId);
                    System.out.println("Tugas berhasil dihapus (jika ditemukan).");
                    break;

                case 3:
                    scheduler.displayTasks();
                    break;

                case 4:
                    System.out.println("Terima kasih!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Pilihan tidak valid.");
            }
        }
    }
}
